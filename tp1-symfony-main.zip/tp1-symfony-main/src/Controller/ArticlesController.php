<?php

namespace App\Controller;

use App\Entity\Article;
use App\Form\ArticleType;
use App\Repository\ArticleRepository;
use App\Repository\CategorieRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class ArticlesController extends AbstractController
{
    #[Route('/articles', name: 'app_articles')]
    public function index(Request $request, ArticleRepository $articleRepository, CategorieRepository $categorieRepository): Response
    {
        // Bonus : filtre optionnel /articles?categorie=ID (paramètre GET)
        $categorie = null;
        if ($request->query->getInt('categorie') > 0) {
            $categorie = $categorieRepository->find($request->query->getInt('categorie'));
        }

        // findAll() = SELECT * FROM article ; findBy([...]) ajoute un WHERE
        $articles = $categorie
            ? $articleRepository->findBy(['categorie' => $categorie])
            : $articleRepository->findAll();

        return $this->render('articles/index.html.twig', [
            'articles' => $articles,
            'categories' => $categorieRepository->findAll(),
            'categorieActive' => $categorie,
        ]);
    }

    // Placée avant /articles/{id} : "nouveau" ne doit pas être pris pour un id
    // (le requirement \d+ de la route detail l'évite de toute façon).
    #[Route('/articles/nouveau', name: 'app_article_nouveau')]
    public function nouveau(Request $request, EntityManagerInterface $em, CategorieRepository $categorieRepository): Response
    {
        $article = new Article();

        // Bonus : /articles/nouveau?categorie=ID pré-sélectionne la catégorie
        if ($request->query->getInt('categorie') > 0) {
            $article->setCategorie($categorieRepository->find($request->query->getInt('categorie')));
        }

        // 1. Création du formulaire lié à l'objet $article
        $form = $this->createForm(ArticleType::class, $article);

        // 2. Si la requête est un POST, les données sont copiées dans $article
        //    puis validées contre les contraintes (#[Assert\...]) de l'entité
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->persist($article); // Doctrine "surveille" l'objet (INSERT préparé)
            $em->flush();           // exécute réellement les requêtes SQL

            // Message flash : affiché une seule fois, après la redirection
            $this->addFlash('success', 'Article créé avec succès !');

            return $this->redirectToRoute('app_articles');
        }

        // GET (formulaire vide) ou POST invalide (formulaire réaffiché avec les erreurs)
        return $this->render('articles/nouveau.html.twig', [
            'formulaire' => $form,
        ]);
    }

    #[Route('/articles/{id}/modifier', name: 'app_article_modifier', requirements: ['id' => '\d+'])]
    public function modifier(Article $article, Request $request, EntityManagerInterface $em): Response
    {
        // Le formulaire est pré-rempli avec les valeurs actuelles de $article
        $form = $this->createForm(ArticleType::class, $article);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // Pas de persist() : $article vient de la base, il est déjà "managed"
            // par Doctrine, qui détecte les changements et génère l'UPDATE au flush().
            $em->flush();

            $this->addFlash('success', 'Article modifié avec succès !');

            return $this->redirectToRoute('app_article_detail', ['id' => $article->getId()]);
        }

        return $this->render('articles/modifier.html.twig', [
            'formulaire' => $form,
            'article' => $article,
        ]);
    }

    // POST uniquement (jamais GET pour une action destructive) + jeton CSRF
    #[Route('/articles/{id}/supprimer', name: 'app_article_supprimer', requirements: ['id' => '\d+'], methods: ['POST'])]
    public function supprimer(Article $article, Request $request, EntityManagerInterface $em): Response
    {
        if ($this->isCsrfTokenValid('supprimer_' . $article->getId(), (string) $request->request->get('_token'))) {
            $em->remove($article);
            $em->flush();

            $this->addFlash('success', 'Article supprimé avec succès.');
        } else {
            $this->addFlash('danger', 'Token CSRF invalide. Suppression annulée.');
        }

        return $this->redirectToRoute('app_articles');
    }

    // Symfony convertit {id} en objet Article (EntityValueResolver) ; 404 si introuvable
    #[Route('/articles/{id}', name: 'app_article_detail', requirements: ['id' => '\d+'])]
    public function detail(Article $article): Response
    {
        return $this->render('articles/detail.html.twig', [
            'article' => $article,
        ]);
    }
}
