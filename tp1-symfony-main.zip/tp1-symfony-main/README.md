# TP1 et TP2 - Symfony 7.4

Projet des TP1 (introduction à Symfony) et TP2 (formulaires, validation, relations Doctrine).

## Installation

```
composer install
php bin/console doctrine:database:create
php bin/console doctrine:migrations:migrate
symfony server:start
```

Il faut créer un fichier `.env.local` avec la connexion à la base :

```
DATABASE_URL="mysql://UTILISATEUR:MOT_DE_PASSE@127.0.0.1:3306/tp1_symfony?serverVersion=8.0"
```

## Réponses TP1

**1.** `symfony check:requirements` affiche "Your system is ready to run Symfony projects" avec 3 recommandations :
- installer un accélérateur PHP (OPcache) : le code est compilé une seule fois, ça améliore les performances
- mettre `realpath_cache_size` à 5M : ça accélère le chargement des fichiers sous Windows
- désactiver `short_open_tag` : pour éviter la confusion entre `<?` et les balises XML

Ce sont seulement des conseils, ils ne bloquent pas l'application.

**2.** `public/` est le seul dossier accessible depuis le navigateur. `index.php` est le point d'entrée : toutes les requêtes passent par lui. Comme ça, les autres dossiers (`src`, `config`, `.env`...) ne sont pas accessibles par une URL.

**3.** La variable `APP_ENV` (`dev` ou `prod`).

**4.** On obtient une erreur 404. La route a la contrainte `\d+` (chiffres seulement), donc `abc` ne correspond à aucune route.

**5.** Après l'exercice 2.2 il y avait 18 routes : 15 de Symfony (`_wdt`, `_profiler`, `_preview_error`) et 3 à moi (`app_accueil`, `app_bonjour`, `app_profil`). À la fin des deux TP il y en a 32, dont 17 à moi.

**6.** `loop.index` est le numéro de l'itération en commençant à 1, `loop.index0` commence à 0.

**7.** La migration contient :

```sql
CREATE TABLE article (id INT AUTO_INCREMENT NOT NULL, titre VARCHAR(255) NOT NULL,
contenu LONGTEXT NOT NULL, auteur VARCHAR(100) NOT NULL, date_creation DATETIME NOT NULL,
publie TINYINT NOT NULL, PRIMARY KEY (id))
```

Elle crée la table `article` à partir de l'entité. Il y a aussi la table `messenger_messages`, ajoutée par le pack webapp.

**8.** Le ParamConverter transforme automatiquement `{id}` de l'URL en objet `Article` (dans Symfony 7 c'est fait par l'EntityValueResolver). Avantages : moins de code qu'un `find()` avec le repository, et une page 404 automatique si l'article n'existe pas.

## Réponses TP2

**1.** Un FormType séparé permet de réutiliser le même formulaire (création et modification) et garde le contrôleur plus court et plus lisible.

**2.** On affiche le formulaire vide (GET). Quand l'utilisateur l'envoie (POST), `handleRequest()` remplit l'objet avec les données, puis `isValid()` vérifie les contraintes. Si c'est invalide, le formulaire est réaffiché avec les erreurs. Si c'est valide, `persist()` et `flush()` enregistrent en base, on ajoute un message flash et on redirige vers la liste.

**3.** `form_row()` affiche le label, le champ et les erreurs en une fois. `form_label()` et `form_widget()` permettent de les placer séparément, utile pour une mise en page personnalisée. On utilise `form_row()` par défaut.

**4.** La validation côté client (HTML5, JavaScript) est dans le navigateur, elle sert au confort de l'utilisateur. La validation côté serveur est faite par Symfony. Il faut toujours valider côté serveur parce que l'utilisateur peut contourner le navigateur (désactiver JavaScript, modifier le HTML, envoyer la requête directement).

**5.** La migration ajoute la colonne `categorie_id` dans `article`, une contrainte `FOREIGN KEY (categorie_id) REFERENCES categorie (id)` et un index. Une clé étrangère est une colonne qui référence la clé primaire d'une autre table. Elle garantit qu'un article ne peut pas être lié à une catégorie qui n'existe pas.

**6.** `createFormBuilder()` est rapide pour un petit formulaire utilisé une seule fois, mais il alourdit le contrôleur et ne peut pas être réutilisé. Un FormType séparé demande plus de fichiers mais il est réutilisable et plus propre.

**7.** Quand on modifie un article, il a été chargé depuis la base, donc Doctrine le gère déjà (état "managed"). Doctrine compare l'objet avec son état d'origine (c'est le Unit of Work) et le `flush()` génère le `UPDATE`. `persist()` sert seulement pour les nouveaux objets.

**8.** Une attaque CSRF force un utilisateur connecté à faire une action à son insu, depuis un autre site (le navigateur envoie les cookies de session automatiquement). Avec un simple GET pour supprimer, un lien ou une image sur un site piégé suffirait à supprimer l'article. C'est pour ça qu'on utilise POST avec un token CSRF que l'attaquant ne peut pas deviner.
